import logging
import random
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, ContextTypes
from apscheduler.schedulers.background import BackgroundScheduler
import sqlite3
import os

# Конфигурация
BOT_TOKEN = '7749975937:AAFHUNchCOG6PSq6Vfhs5FOVGaqGz2CYl_U'  # Получите у @BotFather
DATABASE_NAME = 'plants.db'

# Список из 30 растений
PLANTS_LIST = [
    "Кактус", "Фикус", "Алоэ", "Орхидея", "Гибискус", "Роза", "Тюльпан", "Лаванда",
    "Пион", "Герань", "Хризантема", "Гортензия", "Ирис", "Лилия", "Магнолия",
    "Настурция", "Петуния", "Флокс", "Ромашка", "Азалия", "Бегония", "Вербена",
    "Гвоздика", "Гиацинт", "Клематис", "Крокус", "Лобелия", "Мальва", "Маргаритка",
    "Нарцисс", "Примула"
]

# Проверка существования базы данных
database_exists = os.path.exists(DATABASE_NAME)
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

if not database_exists:
    logging.info(f"Database {DATABASE_NAME} does not exist. It will be created.")

# Инициализация планировщика
scheduler = BackgroundScheduler(timezone="UTC")
scheduler.start()

class PlantDatabase:
    def __init__(self):
        try:
            self.conn = sqlite3.connect(DATABASE_NAME)
            self._init_db()
            logging.info("Successfully connected to the database.")
        except sqlite3.Error as e:
            logging.error(f"Error connecting to database: {e}")
            raise

    def _init_db(self):
        """Инициализация базы данных с тестовыми значениями"""
        try:
            cursor = self.conn.cursor()
            cursor.execute('''CREATE TABLE IF NOT EXISTS users (
                            user_id INTEGER PRIMARY KEY,
                            username TEXT)''')

            cursor.execute('''CREATE TABLE IF NOT EXISTS plants (
                            plant_id INTEGER PRIMARY KEY AUTOINCREMENT,
                            user_id INTEGER,
                            plant_name TEXT,
                            notifications_enabled BOOLEAN DEFAULT 0)''')

            self.conn.commit()
            logging.info("Database initialized successfully.")
        except sqlite3.Error as e:
            logging.error(f"Error initializing database: {e}")
            raise

    def get_or_create_user_plants(self, user_id, username):
        """Получение или создание растений для пользователя"""
        try:
            cursor = self.conn.cursor()
            # Добавление пользователя, если его нет
            cursor.execute("INSERT OR IGNORE INTO users (user_id, username) VALUES (?, ?)", (user_id, username))

            # Проверка наличия растений у пользователя
            cursor.execute("SELECT plant_id FROM plants WHERE user_id = ?", (user_id,))
            existing_plants = cursor.fetchall()

            if not existing_plants:
                # Выбор 5 случайных растений
                random_plants = random.sample(PLANTS_LIST, 5)
                for plant_name in random_plants:
                    cursor.execute("INSERT INTO plants (user_id, plant_name) VALUES (?, ?)", (user_id, plant_name))

            self.conn.commit()
            logging.info(f"Plants for user {user_id} initialized or retrieved.")
        except sqlite3.Error as e:
            logging.error(f"Error getting or creating user plants: {e}")
            raise

    def get_plants(self, user_id):
        try:
            cursor = self.conn.cursor()
            cursor.execute('''SELECT plant_id, plant_name, notifications_enabled
                            FROM plants WHERE user_id = ?''', (user_id,))
            return cursor.fetchall()
        except sqlite3.Error as e:
            logging.error(f"Error fetching plants: {e}")
            return []

    def toggle_notifications(self, plant_id, status):
        try:
            cursor = self.conn.cursor()
            cursor.execute('''UPDATE plants SET notifications_enabled = ?
                            WHERE plant_id = ?''', (status, plant_id))
            self.conn.commit()
        except sqlite3.Error as e:
            logging.error(f"Error updating notifications: {e}")

    def close(self):
        self.conn.close()

db = PlantDatabase()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    db.get_or_create_user_plants(user.id, user.username)
    keyboard = [
        [InlineKeyboardButton("🌿 Мои растения", callback_data='my_plants')],
        [InlineKeyboardButton("➕ Добавить растение", callback_data='add_plant')]
    ]
    await update.message.reply_text(
        f"Добро пожаловать, {user.first_name}!",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def show_plants(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    user_id = query.from_user.id

    plants = db.get_plants(user_id)
    logging.info(f"Plants for user {user_id}: {plants}")  # Логирование для проверки

    if not plants:
        await query.answer("У вас пока нет растений")
        return

    keyboard = [
        [InlineKeyboardButton(f"{'🔔' if plant[2] else '🌱'} {plant[1]}",
         callback_data=f'plant_{plant[0]}')]
        for plant in plants
    ]

    await query.edit_message_text(
        "Ваши растения:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def plant_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    plant_id = query.data.split('_')[1]

    keyboard = [
        [InlineKeyboardButton("✅ Включить уведомления", callback_data=f'enable_{plant_id}')],
        [InlineKeyboardButton("❌ Отключить уведомления", callback_data=f'disable_{plant_id}')]
    ]

    await query.edit_message_text(
        "Управление уведомлениями:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def handle_notification(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    action, plant_id = query.data.split('_')
    user_id = query.from_user.id

    db.toggle_notifications(plant_id, 1 if action == 'enable' else 0)

    if action == 'enable':
        scheduler.add_job(
            send_reminder,
            'interval',
            hours=12,
            args=[context.bot, user_id, plant_id],
            id=f"plant_{plant_id}_user_{user_id}"
        )
        await query.answer("Уведомления включены! 💦")
    else:
        scheduler.remove_job(f"plant_{plant_id}_user_{user_id}")
        await query.answer("Уведомления отключены! 🔕")

def send_reminder(bot, user_id, plant_id):
    try:
        plant = db.conn.execute(
            "SELECT plant_name FROM plants WHERE plant_id = ?",
            (plant_id,)
        ).fetchone()

        if plant:
            bot.send_message(
                chat_id=user_id,
                text=f"🕒 Пора поливать {plant[0]}! 💧"
            )
    except sqlite3.Error as e:
        logging.error(f"Error sending reminder: {e}")

def main():
    # Вставьте ваш токен
    application = ApplicationBuilder().token(BOT_TOKEN).build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(CallbackQueryHandler(show_plants, pattern='^my_plants$'))
    application.add_handler(CallbackQueryHandler(plant_menu, pattern='^plant_'))
    application.add_handler(CallbackQueryHandler(handle_notification, pattern='^(enable|disable)_'))

    application.run_polling()

if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        logging.error("Error occurred", exc_info=e)
    finally:
        db.close()

import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, ContextTypes
from apscheduler.schedulers.background import BackgroundScheduler
import sqlite3

# Конфигурация
BOT_TOKEN = '7749975937:AAFHUNchCOG6PSq6Vfhs5FOVGaqGz2CYl_U'  # Получите у @BotFather
DATABASE_NAME = 'plants.db'

# Инициализация планировщика
scheduler = BackgroundScheduler(timezone="UTC")
scheduler.start()

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

class PlantDatabase:
    def __init__(self):
        self.conn = sqlite3.connect(DATABASE_NAME)
        self._init_db()

    def _init_db(self):
        """Инициализация базы данных с тестовыми значениями"""
        cursor = self.conn.cursor()
        cursor.execute('''CREATE TABLE IF NOT EXISTS users (
                        user_id INTEGER PRIMARY KEY,
                        username TEXT)''')

        cursor.execute('''CREATE TABLE IF NOT EXISTS plants (
                        plant_id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER,
                        plant_name TEXT,
                        notifications_enabled BOOLEAN DEFAULT 0)''')

        # Добавляем тестовые данные
        cursor.execute("INSERT OR IGNORE INTO users VALUES (123456, 'test_user')")
        cursor.execute("INSERT OR IGNORE INTO plants (user_id, plant_name) VALUES (123456, 'Кактус')")
        cursor.execute("INSERT OR IGNORE INTO plants (user_id, plant_name) VALUES (123456, 'Фикус')")
        self.conn.commit()

    def get_plants(self, user_id):
        cursor = self.conn.cursor()
        cursor.execute('''SELECT plant_id, plant_name, notifications_enabled
                        FROM plants WHERE user_id = ?''', (user_id,))
        return cursor.fetchall()

    def toggle_notifications(self, plant_id, status):
        cursor = self.conn.cursor()
        cursor.execute('''UPDATE plants SET notifications_enabled = ?
                        WHERE plant_id = ?''', (status, plant_id))
        self.conn.commit()

db = PlantDatabase()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    keyboard = [
        [InlineKeyboardButton("🌿 Мои растения", callback_data='my_plants')],
        [InlineKeyboardButton("➕ Добавить растение", callback_data='add_plant')]
    ]
    await update.message.reply_text(
        f"Добро пожаловать, {user.first_name}!",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def show_plants(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    user_id = query.from_user.id

    plants = db.get_plants(user_id)

    if not plants:
        await query.answer("У вас пока нет растений")
        return

    keyboard = [
        [InlineKeyboardButton(f"{'🔔' if plant[2] else '🌱'} {plant[1]}",
         callback_data=f'plant_{plant[0]}')]
        for plant in plants
    ]

    await query.edit_message_text(
        "Ваши растения:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def plant_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    plant_id = query.data.split('_')[1]

    keyboard = [
        [InlineKeyboardButton("✅ Включить уведомления", callback_data=f'enable_{plant_id}')],
        [InlineKeyboardButton("❌ Отключить уведомления", callback_data=f'disable_{plant_id}')]
    ]

    await query.edit_message_text(
        "Управление уведомлениями:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def handle_notification(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    action, plant_id = query.data.split('_')
    user_id = query.from_user.id

    db.toggle_notifications(plant_id, 1 if action == 'enable' else 0)

    if action == 'enable':
        scheduler.add_job(
            send_reminder,
            'interval',
            hours=12,
            args=[context.bot, user_id, plant_id],
            id=f"plant_{plant_id}_user_{user_id}"
        )
        await query.answer("Уведомления включены! 💦")
    else:
        scheduler.remove_job(f"plant_{plant_id}_user_{user_id}")
        await query.answer("Уведомления отключены! 🔕")

def send_reminder(bot, user_id, plant_id):
    plant = db.conn.execute(
        "SELECT plant_name FROM plants WHERE plant_id = ?",
        (plant_id,)
    ).fetchone()

    bot.send_message(
        chat_id=user_id,
        text=f"🕒 Пора поливать {plant[0]}! 💧"
    )

def main():
    # Вставьте ваш токен
    application = ApplicationBuilder().token(BOT_TOKEN).build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(CallbackQueryHandler(show_plants, pattern='^my_plants$'))
    application.add_handler(CallbackQueryHandler(plant_menu, pattern='^plant_'))
    application.add_handler(CallbackQueryHandler(handle_notification, pattern='^(enable|disable)_'))

    application.run_polling()

if __name__ == '__main__':
    main()
